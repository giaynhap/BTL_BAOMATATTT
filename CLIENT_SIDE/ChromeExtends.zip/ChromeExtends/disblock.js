
setTi
window.removeClass = removeClass;