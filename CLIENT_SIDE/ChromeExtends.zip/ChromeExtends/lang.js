 lang={};
 lang["vi"] ={
	label_offfb:"Ẩn dang facebook"
}